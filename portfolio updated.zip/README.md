# portfolio
A newly updated version of my portfolio 2024 
